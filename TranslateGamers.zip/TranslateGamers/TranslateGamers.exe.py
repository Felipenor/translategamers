import argparse
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import font as tkfont
from tkinter import colorchooser
import webbrowser
import os
import json
import subprocess
import shutil
import urllib.request
import urllib.parse

try:
    from googletrans import Translator
    HAS_GOOGLETRANS = True
except Exception:
    HAS_GOOGLETRANS = False

try:
    import pyperclip
    HAS_PYPERCLIP = True
except Exception:
    HAS_PYPERCLIP = False

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except Exception:
    HAS_PIL = False

try:
    import pytesseract
    HAS_TESSERACT = True
except Exception:
    HAS_TESSERACT = False

try:
    import mss
    HAS_MSS = True
except Exception:
    HAS_MSS = False
try:
    from langdetect import detect as _ld_detect
    HAS_LANGDETECT = True
    LD_DETECT = _ld_detect
except Exception:
    HAS_LANGDETECT = False
    LD_DETECT = None

try:
    import pystray
    HAS_PYSTRAY = True
except Exception:
    HAS_PYSTRAY = False

LANG_CHOICES = [
    ("auto", "Detectar automaticamente"),
    ("pt", "Português"),
    ("en", "Inglês"),
    ("es", "Espanhol"),
    ("fr", "Francês"),
    ("de", "Alemão"),
    ("it", "Italiano"),
    ("ru", "Russo"),
    ("ja", "Japonês"),
    ("ko", "Coreano"),
    ("zh-cn", "Chinês Simplificado"),
    ("zh-tw", "Chinês Tradicional"),
]

APP_NAME = "TranslateGamers By Felipenor"
UI_LANG_CHOICES = [(code, name) for code, name in LANG_CHOICES if code != "auto"]
UI_TEXTS = {
    "pt": {
        "app_name": "TranslateGamers By Felipenor",
        "open_creator": "Conheça o criador desse programa (clique aqui)",
        "settings_title": "Configurações",
        "origin": "Origem",
        "destination": "Destino",
        "preview": "Pré-visualização",
        "text": "Texto",
        "translate": "Traduzir",
        "copy_translation": "Copiar tradução",
        "viewer": "Visualização",
        "enlarge": "Ampliar",
        "live_translate": "Traduzir enquanto digita",
        "detected": "Detectado",
        "history": "Histórico",
        "from": "Origem",
        "to": "Destino",
        "original": "Original",
        "translated": "Traduzido",
        "monitor_clipboard": "Monitorar clipboard",
        "keep_history": "Manter histórico de traduções",
        "ocr_area": "OCR de área (requer Tesseract)",
        "select_area": "Selecionar área (x,y,w,h)",
        "select_area_visual": "Selecionar área visual",
        "toggle_ocr": "Iniciar/Parar OCR",
        "save": "Salvar",
        "error": "Erro",
        "info": "Info",
        "first_run_title": "Idioma preferido",
        "first_run_label": "Selecione o idioma da interface:",
        "settings_ui_lang": "Idioma da interface",
        "floating_button_side": "Lado do botão flutuante",
        "left": "Esquerda",
        "right": "Direita",
        "theme": "Tema",
        "light_mode": "Claro",
        "dark_mode": "Escuro",
        "ocean_theme": "Ocean",
        "forest_theme": "Forest",
        "custom_theme": "Personalizado",
        "bg_color": "Cor de fundo",
        "fg_color": "Cor do texto",
        "acc_color": "Cor de destaque",
        "font_label": "Fonte",
        "font_size": "Tamanho da fonte",
        "donate_button": "Faça uma doação",
        "donate_title": "Apoio financeiro",
        "donate_message": "Deseja me apoia financeiramente? Doe qualquer valor no PayPal ou via Pix",
        "paypal": "PayPal",
        "pix": "Pix",
        "missing_pyperclip_msg": "Dependência ausente: pyperclip",
        "missing_ocr_deps_msg": "Dependências ausentes para OCR",
        "define_ocr_area_msg": "Defina a área de OCR nas configurações.",
        "missing_visual_deps_msg": "Dependências ausentes para seleção visual",
    },
    "en": {
        "app_name": "TranslateGamers By Felipenor",
        "open_creator": "Meet the creator (click)",
        "settings_title": "Settings",
        "origin": "Source",
        "destination": "Target",
        "preview": "Preview",
        "text": "Text",
        "translate": "Translate",
        "copy_translation": "Copy translation",
        "viewer": "Viewer",
        "enlarge": "Enlarge",
        "live_translate": "Translate while typing",
        "detected": "Detected",
        "history": "History",
        "from": "Source",
        "to": "Target",
        "original": "Original",
        "translated": "Translated",
        "monitor_clipboard": "Monitor clipboard",
        "keep_history": "Keep translation history",
        "ocr_area": "Area OCR (requires Tesseract)",
        "select_area": "Select area (x,y,w,h)",
        "select_area_visual": "Select visual area",
        "toggle_ocr": "Start/Stop OCR",
        "save": "Save",
        "error": "Error",
        "info": "Info",
        "first_run_title": "Preferred language",
        "first_run_label": "Select interface language:",
        "settings_ui_lang": "Interface language",
        "floating_button_side": "Floating button side",
        "left": "Left",
        "right": "Right",
        "theme": "Theme",
        "light_mode": "Light",
        "dark_mode": "Dark",
        "ocean_theme": "Ocean",
        "forest_theme": "Forest",
        "custom_theme": "Custom",
        "bg_color": "Background color",
        "fg_color": "Text color",
        "acc_color": "Accent color",
        "font_label": "Font",
        "font_size": "Font size",
        "donate_button": "Make a donation",
        "donate_title": "Financial Support",
        "donate_message": "Would you like to support me financially? Donate any amount via PayPal or Pix",
        "paypal": "PayPal",
        "pix": "Pix",
        "missing_pyperclip_msg": "Missing dependency: pyperclip",
        "missing_ocr_deps_msg": "Missing dependencies for OCR",
        "define_ocr_area_msg": "Define the OCR area in settings.",
        "missing_visual_deps_msg": "Missing dependencies for visual selection",
    },
    "es": {
        "app_name": "TranslateGamers By Felipenor",
        "open_creator": "Conoce al creador (clic)",
        "settings_title": "Configuración",
        "origin": "Origen",
        "destination": "Destino",
        "preview": "Vista previa",
        "text": "Texto",
        "translate": "Traducir",
        "copy_translation": "Copiar traducción",
        "viewer": "Visualización",
        "enlarge": "Ampliar",
        "live_translate": "Traducir mientras escribe",
        "detected": "Detectado",
        "history": "Historial",
        "from": "Origen",
        "to": "Destino",
        "original": "Original",
        "translated": "Traducido",
        "monitor_clipboard": "Monitorear portapapeles",
        "keep_history": "Mantener historial de traducciones",
        "ocr_area": "OCR de área (requiere Tesseract)",
        "select_area": "Seleccionar área (x,y,w,h)",
        "select_area_visual": "Seleccionar área visual",
        "toggle_ocr": "Iniciar/Detener OCR",
        "save": "Guardar",
        "error": "Error",
        "info": "Info",
        "first_run_title": "Idioma preferido",
        "first_run_label": "Seleccione el idioma de la interfaz:",
        "settings_ui_lang": "Idioma de la interfaz",
        "floating_button_side": "Lado del botón flotante",
        "left": "Izquierda",
        "right": "Derecha",
        "theme": "Tema",
        "light_mode": "Claro",
        "dark_mode": "Oscuro",
        "ocean_theme": "Océano",
        "forest_theme": "Bosque",
        "custom_theme": "Personalizado",
        "bg_color": "Color de fondo",
        "fg_color": "Color del texto",
        "acc_color": "Color de acento",
        "font_label": "Fuente",
        "font_size": "Tamaño de fuente",
        "donate_button": "Hacer una donación",
        "donate_title": "Apoyo financiero",
        "donate_message": "¿Desea apoyarme financieramente? Done cualquier monto vía PayPal o Pix",
        "paypal": "PayPal",
        "pix": "Pix",
        "missing_pyperclip_msg": "Dependencia ausente: pyperclip",
        "missing_ocr_deps_msg": "Dependencias faltantes para OCR",
        "define_ocr_area_msg": "Defina el área de OCR en la configuración.",
        "missing_visual_deps_msg": "Dependencias faltantes para selección visual",
    },
}

_UI_CACHE = {}

def _get_ui_pack(lang):
    base = UI_TEXTS.get("pt", {})
    if lang in UI_TEXTS:
        return UI_TEXTS[lang]
    if lang in _UI_CACHE:
        return _UI_CACHE[lang]
    eng = UI_TEXTS.get("en", {})
    if eng:
        return eng
    return base

def _fetch_ui_pack(lang):
    base = UI_TEXTS.get("pt", {})
    if lang in UI_TEXTS or lang in _UI_CACHE:
        return
    try:
        pack = {}
        for k, v in base.items():
            try:
                pack[k] = _safe_translate(v, lang)
            except Exception:
                pack[k] = v
        _UI_CACHE[lang] = pack
    except Exception:
        pass

_LANG_NAME_CACHE = {}

def _language_display_name(code, ui_lang):
    for c, name in LANG_CHOICES:
        if c == code:
            base_name = name
            break
    else:
        base_name = code
    key = (code, ui_lang)
    if key in _LANG_NAME_CACHE:
        return _LANG_NAME_CACHE[key]
    _LANG_NAME_CACHE[key] = base_name
    return base_name

def _normalize_lang_for_mymemory(code):
    c = (code or "").lower()
    if c == "zh-cn":
        return "zh-CN"
    if c == "zh-tw":
        return "zh-TW"
    return c

def _normalize_detected_lang(code):
    try:
        c = (code or "").lower()
        if c.startswith("zh"):
            if "tw" in c or "hant" in c:
                return "zh-tw"
            return "zh-cn"
        base = c.split("-", 1)[0]
        return base
    except Exception:
        return None

def _detect_lang(text):
    try:
        tr = ensure_translator()
        det = tr.detect(text)
        return _normalize_detected_lang(getattr(det, "lang", None))
    except Exception:
        pass
    try:
        if LD_DETECT is None and not HAS_LANGDETECT:
            _pip_install("langdetect")
            try:
                from langdetect import detect as _ld
                globals()["LD_DETECT"] = _ld
            except Exception:
                globals()["LD_DETECT"] = None
        if LD_DETECT is not None:
            return _normalize_detected_lang(LD_DETECT(text))
    except Exception:
        pass
    return None

def _safe_translate(text, dest, src=None):
    gtx = _gtx_translate(text, dest, src)
    if gtx is not None and isinstance(gtx.get("translated"), str):
        return gtx["translated"]
    try:
        tr = ensure_translator()
        if src in (None, "auto"):
            return tr.translate(text, dest=dest).text
        return tr.translate(text, src=src, dest=dest).text
    except Exception:
        pass
    t = _mymemory_translate(text, dest, src or "auto")
    if t:
        return t
    return text

def _gtx_translate(text, target, source=None):
    try:
        sl = _normalize_lang_for_mymemory(source if source not in (None, "auto") else "auto")
        q = urllib.parse.quote(text)
        tl = _normalize_lang_for_mymemory(target)
        url = f"https://translate.googleapis.com/translate_a/single?client=gtx&sl={sl}&tl={tl}&dt=t&q={q}"
        with urllib.request.urlopen(url, timeout=6) as resp:
            data = resp.read().decode("utf-8")
        arr = json.loads(data)
        trans = "".join(seg[0] for seg in (arr[0] or []) if isinstance(seg, list) and seg)
        src = arr[2] if len(arr) > 2 and isinstance(arr[2], str) else (source or "auto")
        if trans:
            return {"src": src, "translated": trans}
    except Exception:
        pass
    return None

def _mymemory_translate(text, dest, src):
    try:
        q = urllib.parse.quote(text)
        s = _normalize_lang_for_mymemory(src)
        if s in (None, "", "auto"):
            s = "en"
        lp = f"{s}|{_normalize_lang_for_mymemory(dest)}"
        url = f"https://api.mymemory.translated.net/get?q={q}&langpair={lp}"
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = resp.read().decode("utf-8")
        j = json.loads(data)
        t = j.get("responseData", {}).get("translatedText")
        if isinstance(t, str) and t:
            bad = ("RFC3066" in t) or ("NO CONTENT" in t) or ("INVALID" in t)
            if not bad:
                return t
        matches = j.get("matches", [])
        best = None
        best_score = -1.0
        for m in matches:
            trans = m.get("translation")
            quality = m.get("quality")
            try:
                score = float(quality)
            except Exception:
                score = 0.0
            if isinstance(trans, str) and trans and score >= best_score:
                best = trans
                best_score = score
        if best:
            return best
    except Exception:
        pass
    return None

def _pip_install(spec):
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", spec], check=False)
    except Exception:
        pass

def _ensure_imports():
    global Translator, HAS_GOOGLETRANS, pyperclip, HAS_PYPERCLIP, Image, ImageTk, HAS_PIL, pytesseract, HAS_TESSERACT, mss, HAS_MSS
    if not HAS_GOOGLETRANS:
        _pip_install("googletrans==4.0.0rc1")
        try:
            from googletrans import Translator as _T
            Translator = _T
            HAS_GOOGLETRANS = True
        except Exception:
            HAS_GOOGLETRANS = False
    if not HAS_PYPERCLIP:
        _pip_install("pyperclip")
        try:
            import pyperclip as _pc
            pyperclip = _pc
            HAS_PYPERCLIP = True
        except Exception:
            HAS_PYPERCLIP = False
    if not HAS_PIL:
        _pip_install("pillow")
        try:
            from PIL import Image as _I, ImageTk as _IT
            Image = _I
            ImageTk = _IT
            HAS_PIL = True
        except Exception:
            HAS_PIL = False
    if not HAS_MSS:
        _pip_install("mss")
        try:
            import mss as _m
            mss = _m
            HAS_MSS = True
        except Exception:
            HAS_MSS = False
    if not HAS_TESSERACT:
        _pip_install("pytesseract")
        try:
            import pytesseract as _pt
            pytesseract = _pt
            HAS_TESSERACT = True
        except Exception:
            HAS_TESSERACT = False

def _find_tesseract_cmd():
    candidates = [
        os.path.join("C:\\Program Files", "Tesseract-OCR", "tesseract.exe"),
        os.path.join("C:\\Program Files (x86)", "Tesseract-OCR", "tesseract.exe"),
        shutil.which("tesseract"),
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    return None

_translator = None

def ensure_translator():
    global _translator
    if not HAS_GOOGLETRANS:
        _ensure_imports()
    if not HAS_GOOGLETRANS:
        raise RuntimeError("Dependência ausente: googletrans")
    if _translator is None:
        try:
            _translator = Translator(service_urls=["translate.googleapis.com"])
        except Exception:
            _translator = Translator()
    return _translator

def translate_text(text, target, source=None):
    if not text.strip():
        return {"src": source or "auto", "dest": target, "text": text, "translated": ""}
    try:
        translator = ensure_translator()
        if source in (None, "auto"):
            result = translator.translate(text, dest=target)
        else:
            result = translator.translate(text, src=source, dest=target)
        return {"src": result.src, "dest": result.dest, "text": text, "translated": result.text}
    except Exception:
        gtx = _gtx_translate(text, target, source)
        if gtx is not None:
            return {"src": gtx["src"], "dest": target, "text": text, "translated": gtx["translated"]}
        det = None
        if source in (None, "auto"):
            det = _detect_lang(text)
        fm_src = det if det not in (None, "auto") else (source if source not in (None, "auto") else "en")
        t = _mymemory_translate(text, target, fm_src)
        if t is None:
            t = text
        return {"src": det or source or "auto", "dest": target, "text": text, "translated": t}

def cli_mode(args):
    if args.text is not None:
        preview = f"Pré-visualização: texto='{args.text}' destino='{args.target}' origem='{args.source or 'auto'}'"
        print(preview)
        data = translate_text(args.text, args.target, args.source)
        print(f"Origem: {data['src']} → Destino: {data['dest']}")
        print(f"Original: {data['text']}")
        print(f"Traduzido: {data['translated']}")
        return
    print(f"Destino: {args.target}")
    print("Digite o texto para traduzir. Linha vazia encerra.")
    while True:
        try:
            line = input("> ").rstrip("\n")
        except EOFError:
            break
        if line == "":
            break
        preview = f"Pré-visualização: texto='{line}' destino='{args.target}' origem='{args.source or 'auto'}'"
        print(preview)
        data = translate_text(line, args.target, args.source)
        print(f"Origem: {data['src']} → Destino: {data['dest']}")
        print(f"Original: {data['text']}")
        print(f"Traduzido: {data['translated']}")

class TranslatorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.attributes("-topmost", True)
        self.overrideredirect(False)
        self.resizable(True, True)
        self.minsize(560, 460)
        self.geometry("680x560+20+20")
        self.target_var = tk.StringVar(value="pt")
        self.source_var = tk.StringVar(value="auto")
        self.preview_var = tk.StringVar(value="")
        self.last_translation = ""
        self.live_translate_var = tk.BooleanVar(value=False)
        self.monitor_clipboard_var = tk.BooleanVar(value=False)
        self.keep_history_var = tk.BooleanVar(value=True)
        self.ocr_running = False
        self.clipboard_running = False
        self.ocr_bbox = None
        self._live_job = None
        self._drag_x = 0
        self._drag_y = 0
        self._in_tray = False
        self.tray_icon = None
        self.floating_win = None
        self.floating_side = "right"
        self.theme = "light"
        self.custom_palette = {}
        self.font_family = "Segoe UI"
        self.font_size = 10
        self._font = None
        self.config_path = os.path.join(os.path.expanduser("~"), ".translategamers.json")
        self.ui_lang = "pt"
        self._load_config()
        self._build_overlay_bar()
        self._build_ui()
        if not getattr(self, "_has_config", False):
            self._first_run_language_prompt()
        try:
            self._load_ui_pack_async(self.ui_lang)
        except Exception:
            pass
        self._apply_ui_lang()
        self._apply_theme()
        try:
            if getattr(self, "ui_lang", "pt") != "pt":
                self._precache_language_names_async()
        except Exception:
            pass
        self.bind("<Unmap>", self._on_unmap)
        self.bind("<Map>", self._on_map)

    def _build_overlay_bar(self):
        bar = ttk.Frame(self)
        bar.pack(fill=tk.X)
        self.title_label = ttk.Label(bar, text=APP_NAME, anchor=tk.W)
        self.title_label.pack(side=tk.LEFT, padx=8, pady=4)
        right_box = ttk.Frame(bar)
        right_box.pack(side=tk.RIGHT, padx=8, pady=4)
        link_box = ttk.Frame(right_box)
        link_box.pack(anchor=tk.E)
        self.creator_btn = ttk.Button(link_box, text="Conheça o criador desse programa (clique)", command=self.open_creator_link)
        self.creator_btn.pack(side=tk.RIGHT, padx=(4, 0))
        self.donate_btn = ttk.Button(link_box, text=self._t("donate_button"), command=self.open_donate_popup)
        self.donate_btn.pack(side=tk.RIGHT)
        settings_box = ttk.Frame(right_box)
        settings_box.pack(anchor=tk.E, pady=(4, 0))
        self.settings_btn = ttk.Button(settings_box, text="⚙", width=3, command=self.open_settings)
        self.settings_btn.pack(side=tk.RIGHT)
        bar.bind("<ButtonPress-1>", self._on_bar_press)
        bar.bind("<B1-Motion>", self._on_bar_move)
        bar.bind("<ButtonRelease-1>", self._on_bar_release)

    def _build_ui(self):
        top = ttk.Frame(self)
        top.pack(fill=tk.X, padx=12, pady=8)
        self.lbl_origin = ttk.Label(top, text="Origem")
        self.lbl_origin.pack(side=tk.LEFT)
        self.src_cb = ttk.Combobox(top, state="readonly", width=18, textvariable=self.source_var)
        self.src_cb["values"] = [f"{code} - {name}" for code, name in LANG_CHOICES]
        self.src_cb.current(0)
        self.src_cb.pack(side=tk.LEFT, padx=(8, 16))
        self.lbl_destination = ttk.Label(top, text="Destino")
        self.lbl_destination.pack(side=tk.LEFT)
        self.dst_cb = ttk.Combobox(top, state="readonly", width=18, textvariable=self.target_var)
        self.dst_cb["values"] = [f"{code} - {name}" for code, name in LANG_CHOICES[1:]]
        self.dst_cb.current(0)
        self.dst_cb.pack(side=tk.LEFT, padx=8)

        mid = ttk.Frame(self)
        mid.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 8))
        self.lbl_text = ttk.Label(mid, text="Texto")
        self.lbl_text.pack(anchor=tk.W)
        self.input_text = tk.Text(mid, height=5, wrap=tk.WORD)
        self.input_text.pack(fill=tk.BOTH, expand=True)
        self.input_text.bind("<KeyRelease>", self._on_input_key)

        actions = ttk.Frame(self)
        actions.pack(fill=tk.X, padx=12, pady=8)
        self.btn_preview = ttk.Button(actions, text="Pré-visualizar", command=self.on_preview)
        self.btn_preview.pack(side=tk.LEFT)
        self.btn_translate = ttk.Button(actions, text="Traduzir", command=self.on_translate)
        self.btn_translate.pack(side=tk.LEFT, padx=8)
        self.btn_copy = ttk.Button(actions, text="Copiar tradução", command=self.on_copy_translation)
        self.btn_copy.pack(side=tk.LEFT, padx=8)
        self.btn_enlarge = ttk.Button(actions, text="Ampliar", command=self.open_viewer)
        self.btn_enlarge.pack(side=tk.LEFT)

        actions2 = ttk.Frame(self)
        actions2.pack(fill=tk.X, padx=12, pady=(0, 8))
        self.cb_live = ttk.Checkbutton(actions2, text="Traduzir enquanto digita", variable=self.live_translate_var, command=self.on_toggle_live)
        self.cb_live.pack(anchor=tk.W)

        preview_box = ttk.Frame(self)
        preview_box.pack(fill=tk.X, padx=12, pady=(0, 8))
        self.lbl_preview = ttk.Label(preview_box, text="Pré-visualização")
        self.lbl_preview.pack(anchor=tk.W)
        self.preview_label = ttk.Label(preview_box, textvariable=self.preview_var)
        self.preview_label.pack(anchor=tk.W)

        out = ttk.Frame(self)
        out.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 12))
        self.lbl_history = ttk.Label(out, text="Histórico")
        self.lbl_history.pack(anchor=tk.W)
        self.output_text = tk.Text(out, height=18, wrap=tk.WORD)
        self.output_text.pack(fill=tk.BOTH, expand=True)
        self.output_text.configure(state=tk.DISABLED)

    def _parse_lang(self, value):
        if " - " in value:
            return value.split(" - ", 1)[0]
        return value

    def on_preview(self):
        text = self.input_text.get("1.0", tk.END).strip()
        src = self._parse_lang(self.source_var.get())
        dst = self._parse_lang(self.target_var.get())
        if src == "auto":
            det = _detect_lang(text) or "auto"
            self.preview_var.set(f"texto='{text}' destino='{dst}' origem='{src}' {self._t('detected').lower()}='{det}'")
        else:
            self.preview_var.set(f"texto='{text}' destino='{dst}' origem='{src}'")

    def on_translate(self):
        text = self.input_text.get("1.0", tk.END).strip()
        src = self._parse_lang(self.source_var.get())
        dst = self._parse_lang(self.target_var.get())
        self.preview_var.set(f"texto='{text}' destino='{dst}' origem='{src}'")
        def run():
            try:
                data = translate_text(text, dst, None if src == "auto" else src)
            except Exception as e:
                self.after(0, lambda: messagebox.showerror(self._t("error"), str(e)))
                return
            self.after(0, lambda: self._append_history(data))
        threading.Thread(target=run, daemon=True).start()

    def _append_history(self, data):
        self.output_text.configure(state=tk.NORMAL)
        if not self.keep_history_var.get():
            self.output_text.delete("1.0", tk.END)
        ui = getattr(self, "ui_lang", "pt")
        src_name = _language_display_name(data['src'], ui)
        dst_name = _language_display_name(data['dest'], ui)
        self.output_text.insert(tk.END, f"{self._t('from')}: {src_name} → {self._t('to')}: {dst_name}\n")
        if self._parse_lang(self.source_var.get()) == "auto":
            self.output_text.insert(tk.END, f"{self._t('detected')}: {src_name}\n")
        self.output_text.insert(tk.END, f"{self._t('original')}: {data['text']}\n")
        self.output_text.insert(tk.END, f"{self._t('translated')}: {data['translated']}\n\n")
        self.output_text.configure(state=tk.DISABLED)
        self.last_translation = data['translated']

    def _t(self, key):
        lang = getattr(self, "ui_lang", "pt")
        pack = _get_ui_pack(lang)
        base = _get_ui_pack("pt")
        return pack.get(key, base.get(key, key))

    def _apply_ui_lang(self):
        try:
            self.title(self._t("app_name"))
            self.title_label.configure(text=self._t("app_name"))
            self.creator_btn.configure(text=self._t("open_creator"))
            try:
                self.donate_btn.configure(text=self._t("donate_button"))
            except Exception:
                pass
            self.lbl_origin.configure(text=self._t("origin"))
            self.lbl_destination.configure(text=self._t("destination"))
            self.lbl_text.configure(text=self._t("text"))
            self.btn_preview.configure(text=self._t("preview"))
            self.btn_translate.configure(text=self._t("translate"))
            self.btn_copy.configure(text=self._t("copy_translation"))
            self.btn_enlarge.configure(text=self._t("enlarge"))
            self.cb_live.configure(text=self._t("live_translate"))
            self.lbl_preview.configure(text=self._t("preview"))
            self.lbl_history.configure(text=self._t("history"))
            self._refresh_language_comboboxes()
            self._apply_settings_lang()
        except Exception:
            pass

    def open_donate_popup(self):
        try:
            win = tk.Toplevel(self)
            win.title(self._t("donate_title"))
            win.attributes("-topmost", True)
            win.resizable(False, False)
            frm = ttk.Frame(win)
            frm.pack(padx=12, pady=12)
            ttk.Label(frm, text=self._t("donate_message")).pack(anchor=tk.W, pady=(0, 8))
            def open_paypal():
                try:
                    webbrowser.open("https://www.paypal.com/donate?business=felipeczs41@gmail.com&currency_code=BRL", new=2)
                except Exception:
                    pass
            def open_pix():
                try:
                    webbrowser.open("https://livepix.gg/felipenor", new=2)
                except Exception:
                    pass
            ttk.Button(frm, text=self._t("paypal"), command=open_paypal).pack(side=tk.LEFT, padx=(0, 8))
            ttk.Button(frm, text=self._t("pix"), command=open_pix).pack(side=tk.LEFT)
        except Exception:
            pass

    def _refresh_language_comboboxes(self):
        try:
            ui = getattr(self, "ui_lang", "pt")
            src_vals = [f"{code} - {_language_display_name(code, ui)}" for code, _ in LANG_CHOICES]
            dst_vals = [f"{code} - {_language_display_name(code, ui)}" for code, _ in LANG_CHOICES[1:]]
            self.src_cb["values"] = src_vals
            self.dst_cb["values"] = dst_vals
            src_code = self._parse_lang(self.source_var.get())
            dst_code = self._parse_lang(self.target_var.get())
            try:
                idx_src = [c for c, _ in LANG_CHOICES].index(src_code)
            except Exception:
                idx_src = 0
            try:
                idx_dst = [c for c, _ in LANG_CHOICES[1:]].index(dst_code)
            except Exception:
                idx_dst = 0
            self.src_cb.current(idx_src)
            self.dst_cb.current(idx_dst)
        except Exception:
            pass

    def _load_ui_pack_async(self, lang):
        if lang in UI_TEXTS or lang in _UI_CACHE:
            return
        def run():
            _fetch_ui_pack(lang)
            try:
                self.after(0, self._apply_ui_lang)
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()

    def _precache_language_names_async(self):
        ui = getattr(self, "ui_lang", "pt")
        if ui == "pt":
            return
        def run():
            try:
                for code, name in LANG_CHOICES:
                    key = (code, ui)
                    if key in _LANG_NAME_CACHE:
                        continue
                    try:
                        txt = _safe_translate(name, ui)
                    except Exception:
                        txt = name
                    _LANG_NAME_CACHE[key] = txt
                try:
                    self.after(0, self._refresh_language_comboboxes)
                except Exception:
                    pass
            except Exception:
                pass
        threading.Thread(target=run, daemon=True).start()

    def _load_config(self):
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        except Exception:
            self._has_config = False
            return
        try:
            t = cfg.get("target")
            s = cfg.get("source")
            b = cfg.get("ocr_bbox")
            u = cfg.get("ui_lang")
            fs = cfg.get("floating_side")
            th = cfg.get("theme")
            cp = cfg.get("custom_palette")
            ff = cfg.get("font_family")
            fz = cfg.get("font_size")
            if t:
                self.target_var.set(t)
            if s:
                self.source_var.set(s)
            if b:
                self.ocr_bbox = tuple(b)
            if u:
                self.ui_lang = u
            if fs in ("left", "right"):
                self.floating_side = fs
            if th in ("light", "dark", "ocean", "forest", "custom"):
                self.theme = th
            if isinstance(cp, dict):
                self.custom_palette = {
                    "bg": cp.get("bg"),
                    "fg": cp.get("fg"),
                    "acc": cp.get("acc"),
                }
            if isinstance(ff, str) and ff:
                self.font_family = ff
            try:
                fzi = int(fz)
                if 6 <= fzi <= 48:
                    self.font_size = fzi
            except Exception:
                pass
            self._has_config = True
        except Exception:
            self._has_config = False

    def _save_config(self):
        cfg = {
            "target": self._parse_lang(self.target_var.get()),
            "source": self._parse_lang(self.source_var.get()),
            "ocr_bbox": list(self.ocr_bbox) if self.ocr_bbox else None,
            "ui_lang": getattr(self, "ui_lang", "pt"),
            "floating_side": getattr(self, "floating_side", "right"),
            "theme": getattr(self, "theme", "light"),
            "custom_palette": getattr(self, "custom_palette", {}),
            "font_family": getattr(self, "font_family", "Segoe UI"),
            "font_size": getattr(self, "font_size", 10),
        }
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(cfg, f)
            self._has_config = True
        except Exception:
            pass

    def _first_run_language_prompt(self):
        win = tk.Toplevel(self)
        win.title(UI_TEXTS["pt"]["first_run_title"])
        win.attributes("-topmost", True)
        win.resizable(False, False)
        frm = ttk.Frame(win)
        frm.pack(padx=12, pady=12)
        ttk.Label(frm, text=UI_TEXTS["pt"]["first_run_label"]).pack(anchor=tk.W)
        var_ui = tk.StringVar(value="pt")
        cb_ui = ttk.Combobox(frm, state="readonly", width=24, textvariable=var_ui)
        cb_ui["values"] = [f"{code} - {name}" for code, name in UI_LANG_CHOICES]
        cb_ui.current(0)
        cb_ui.pack(pady=8)
        def save():
            code = self._parse_lang(var_ui.get())
            self.ui_lang = code
            if code != "auto":
                self.target_var.set(code)
            self._save_config()
            win.destroy()
        ttk.Button(frm, text=UI_TEXTS["pt"]["save"], command=save).pack()

    def _on_bar_press(self, event):
        self._drag_x = event.x
        self._drag_y = event.y

    def _on_bar_move(self, event):
        x = self.winfo_x() + event.x - self._drag_x
        y = self.winfo_y() + event.y - self._drag_y
        self.geometry(f"+{x}+{y}")

    def _on_bar_release(self, event):
        pass

    def _create_tray_image(self):
        try:
            if not HAS_PIL:
                _ensure_imports()
            if not HAS_PIL:
                return None
            img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
            for x in range(32):
                for y in range(32):
                    if (x - 16) ** 2 + (y - 16) ** 2 <= 14 ** 2:
                        img.putpixel((x, y), (30, 144, 255, 255))
            return img
        except Exception:
            return None

    def _show_tray_icon(self):
        if self._in_tray:
            return
        try:
            try:
                import pystray as _ps
                _ = _ps.Icon
            except Exception:
                _pip_install("pystray")
                try:
                    import pystray as _ps
                    _ = _ps.Icon
                except Exception:
                    return
            img = self._create_tray_image()
            if img is not None:
                menu = pystray.Menu(
                    pystray.MenuItem("Mostrar", lambda: self._restore_from_tray(), default=True),
                    pystray.MenuItem("Sair", lambda: self._quit_from_tray())
                )
                self.tray_icon = pystray.Icon(APP_NAME, img, APP_NAME, menu=menu)
            else:
                self.tray_icon = pystray.Icon(APP_NAME)
            self._in_tray = True
            try:
                self.tray_icon.run_detached()
            except Exception:
                threading.Thread(target=self.tray_icon.run, daemon=True).start()
        except Exception:
            self._in_tray = False

    def _restore_from_tray(self):
        try:
            if self.tray_icon is not None:
                try:
                    self.tray_icon.stop()
                except Exception:
                    pass
                self.tray_icon = None
            self._in_tray = False
            try:
                self.deiconify()
            except Exception:
                pass
            try:
                self.state("normal")
            except Exception:
                pass
        except Exception:
            pass

    def _quit_from_tray(self):
        try:
            if self.tray_icon is not None:
                try:
                    self.tray_icon.stop()
                except Exception:
                    pass
                self.tray_icon = None
            self._in_tray = False
        except Exception:
            pass
        try:
            self.destroy()
        except Exception:
            pass

    def _on_unmap(self, event):
        try:
            st = None
            try:
                st = self.state()
            except Exception:
                pass
            if st == "iconic":
                try:
                    self.withdraw()
                except Exception:
                    pass
                self._show_floating_button()
        except Exception:
            pass

    def _on_map(self, event):
        try:
            self._hide_floating_button()
        except Exception:
            pass

    def _show_floating_button(self):
        if self.floating_win is not None:
            return
        win = tk.Toplevel(self)
        self.floating_win = win
        try:
            win.overrideredirect(True)
        except Exception:
            pass
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        w, h = 44, 44
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        x = sw - w - 8 if self.floating_side == "right" else 8
        y = sh // 2 - h // 2
        win.geometry(f"{w}x{h}+{x}+{y}")
        bg, fg, acc = self._palette()
        try:
            btn = tk.Button(win, text="🌐", command=self._restore_from_floating, bg=acc, fg=fg, activebackground=bg, activeforeground=fg, bd=1, relief=tk.SOLID)
        except Exception:
            btn = ttk.Button(win, text="🌐", command=self._restore_from_floating)
        btn.pack(fill=tk.BOTH, expand=True)

    def _hide_floating_button(self):
        try:
            if self.floating_win is not None:
                self.floating_win.destroy()
                self.floating_win = None
        except Exception:
            self.floating_win = None

    def _restore_from_floating(self):
        try:
            self._hide_floating_button()
            try:
                self.deiconify()
            except Exception:
                pass
            try:
                self.state("normal")
            except Exception:
                pass
        except Exception:
            pass

    def on_copy_translation(self):
        try:
            text = self.last_translation or ""
            if not text:
                return
            self.clipboard_clear()
            self.clipboard_append(text)
        except Exception:
            pass

    def open_viewer(self):
        if not self.last_translation:
            return
        win = tk.Toplevel(self)
        win.title(self._t("viewer"))
        win.attributes("-topmost", True)
        win.geometry("640x240")
        txt = tk.Text(win, wrap=tk.WORD)
        txt.pack(fill=tk.BOTH, expand=True)
        txt.configure(font=("Segoe UI", 12))
        txt.insert(tk.END, self.last_translation)
        txt.configure(state=tk.DISABLED)

    def open_creator_link(self):
        try:
            webbrowser.open("https://linkr.bio/felipenor", new=2)
        except Exception:
            pass

    def _on_input_key(self, event):
        if not self.live_translate_var.get():
            return
        if self._live_job is not None:
            try:
                self.after_cancel(self._live_job)
            except Exception:
                pass
        self._live_job = self.after(300, self.on_translate)

    def on_toggle_live(self):
        if not self.live_translate_var.get():
            if self._live_job is not None:
                try:
                    self.after_cancel(self._live_job)
                except Exception:
                    pass
                self._live_job = None

    def open_settings(self):
        win = tk.Toplevel(self)
        self.settings_win = win
        win.title(self._t("settings_title"))
        win.attributes("-topmost", True)
        win.resizable(False, False)
        frame = ttk.Frame(win)
        frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)
        cb_clip = ttk.Checkbutton(frame, text=self._t("monitor_clipboard"), variable=self.monitor_clipboard_var, command=self._toggle_clipboard_monitor)
        cb_clip.pack(anchor=tk.W, pady=(0, 8))
        cb_keep = ttk.Checkbutton(frame, text=self._t("keep_history"), variable=self.keep_history_var)
        cb_keep.pack(anchor=tk.W, pady=(0, 8))
        ocr_label = ttk.Label(frame, text=self._t("ocr_area"))
        ocr_label.pack(anchor=tk.W)
        btn_sel = ttk.Button(frame, text=self._t("select_area"), command=self._select_bbox_dialog)
        btn_sel.pack(anchor=tk.W, pady=4)
        btn_sel_visual = ttk.Button(frame, text=self._t("select_area_visual"), command=self._select_bbox_visual)
        btn_sel_visual.pack(anchor=tk.W, pady=4)
        btn_ocr = ttk.Button(frame, text=self._t("toggle_ocr"), command=self._toggle_ocr)
        btn_ocr.pack(anchor=tk.W)
        lbl_ui = ttk.Label(frame, text=self._t("settings_ui_lang"))
        lbl_ui.pack(anchor=tk.W, pady=(8, 2))
        ui_var = tk.StringVar(value=f"{self.ui_lang} - " + dict(UI_LANG_CHOICES).get(self.ui_lang, ""))
        ui_cb = ttk.Combobox(frame, state="readonly", width=24, textvariable=ui_var)
        ui_cb["values"] = [f"{code} - {name}" for code, name in UI_LANG_CHOICES]
        ui_cb.pack(anchor=tk.W)
        def on_ui_change(e=None):
            code = self._parse_lang(ui_var.get())
            self.ui_lang = code
            try:
                _fetch_ui_pack(code)
            except Exception:
                pass
            self._apply_ui_lang()
            self._save_config()
            self._apply_settings_lang()
            try:
                self._precache_language_names_async()
            except Exception:
                pass
        ui_cb.bind("<<ComboboxSelected>>", on_ui_change)

        lbl_side = ttk.Label(frame, text=self._t("floating_button_side"))
        lbl_side.pack(anchor=tk.W, pady=(8, 2))
        side_var = tk.StringVar(value=self._t("right") if self.floating_side == "right" else self._t("left"))
        side_cb = ttk.Combobox(frame, state="readonly", width=24, textvariable=side_var)
        side_cb["values"] = [self._t("left"), self._t("right")]
        side_cb.pack(anchor=tk.W)
        def on_side_change(e=None):
            disp = side_var.get()
            code = "left" if disp == self._t("left") else "right"
            self.floating_side = code
            self._save_config()
        side_cb.bind("<<ComboboxSelected>>", on_side_change)

        lbl_theme = ttk.Label(frame, text=self._t("theme"))
        lbl_theme.pack(anchor=tk.W, pady=(8, 2))
        theme_var = tk.StringVar(value=self._t("dark_mode") if self.theme == "dark" else (self._t("light_mode") if self.theme == "light" else (self._t("ocean_theme") if self.theme == "ocean" else (self._t("forest_theme") if self.theme == "forest" else self._t("custom_theme")))) )
        theme_cb = ttk.Combobox(frame, state="readonly", width=24, textvariable=theme_var)
        theme_cb["values"] = [self._t("light_mode"), self._t("dark_mode"), self._t("ocean_theme"), self._t("forest_theme"), self._t("custom_theme")]
        theme_cb.pack(anchor=tk.W)
        def on_theme_change(e=None):
            disp = theme_var.get()
            if disp == self._t("dark_mode"):
                self.theme = "dark"
            elif disp == self._t("light_mode"):
                self.theme = "light"
            elif disp == self._t("ocean_theme"):
                self.theme = "ocean"
            elif disp == self._t("forest_theme"):
                self.theme = "forest"
            else:
                self.theme = "custom"
            self._apply_theme()
            self._save_config()
            self._apply_settings_lang()
        theme_cb.bind("<<ComboboxSelected>>", on_theme_change)
        lbl_bg = ttk.Label(frame, text=self._t("bg_color"))
        lbl_bg.pack(anchor=tk.W, pady=(8, 2))
        def pick_bg():
            c = colorchooser.askcolor()[1]
            if c:
                self.custom_palette["bg"] = c
                self._apply_theme()
                self._save_config()
        btn_bg = ttk.Button(frame, text=self._t("bg_color"), command=pick_bg)
        btn_bg.pack(anchor=tk.W)
        lbl_fg = ttk.Label(frame, text=self._t("fg_color"))
        lbl_fg.pack(anchor=tk.W, pady=(8, 2))
        def pick_fg():
            c = colorchooser.askcolor()[1]
            if c:
                self.custom_palette["fg"] = c
                self._apply_theme()
                self._save_config()
        btn_fg = ttk.Button(frame, text=self._t("fg_color"), command=pick_fg)
        btn_fg.pack(anchor=tk.W)
        lbl_acc = ttk.Label(frame, text=self._t("acc_color"))
        lbl_acc.pack(anchor=tk.W, pady=(8, 2))
        def pick_acc():
            c = colorchooser.askcolor()[1]
            if c:
                self.custom_palette["acc"] = c
                self._apply_theme()
                self._save_config()
        btn_acc = ttk.Button(frame, text=self._t("acc_color"), command=pick_acc)
        btn_acc.pack(anchor=tk.W)
        lbl_font = ttk.Label(frame, text=self._t("font_label"))
        lbl_font.pack(anchor=tk.W, pady=(8, 2))
        try:
            fams = sorted(set(list(tkfont.families(self)) + ["Jokerman"]))
        except Exception:
            fams = [self.font_family]
        font_var = tk.StringVar(value=self.font_family)
        font_cb = ttk.Combobox(frame, state="readonly", width=24, textvariable=font_var)
        font_cb["values"] = fams
        font_cb.pack(anchor=tk.W)
        def on_font_change(e=None):
            self.font_family = font_var.get()
            try:
                self._font = tkfont.Font(family=self.font_family, size=self.font_size)
            except Exception:
                pass
            self._apply_theme()
            self._save_config()
            self._apply_settings_lang()
        font_cb.bind("<<ComboboxSelected>>", on_font_change)
        lbl_fs = ttk.Label(frame, text=self._t("font_size"))
        lbl_fs.pack(anchor=tk.W, pady=(8, 2))
        fs_var = tk.StringVar(value=str(self.font_size))
        fs_cb = ttk.Combobox(frame, state="readonly", width=8, textvariable=fs_var)
        fs_cb["values"] = ["9","10","11","12","14","16","18"]
        fs_cb.pack(anchor=tk.W)
        def on_fs_change(e=None):
            try:
                self.font_size = int(fs_var.get())
            except Exception:
                self.font_size = 10
            try:
                self._font = tkfont.Font(family=self.font_family, size=self.font_size)
            except Exception:
                pass
            self._apply_theme()
            self._save_config()
            self._apply_settings_lang()
        fs_cb.bind("<<ComboboxSelected>>", on_fs_change)
        self.settings_widgets = {
            "cb_clip": cb_clip,
            "cb_keep": cb_keep,
            "ocr_label": ocr_label,
            "btn_sel": btn_sel,
            "btn_sel_visual": btn_sel_visual,
            "btn_ocr": btn_ocr,
            "lbl_ui": lbl_ui,
            "ui_cb": ui_cb,
            "lbl_side": lbl_side,
            "side_cb": side_cb,
            "lbl_theme": lbl_theme,
            "theme_cb": theme_cb,
            "lbl_bg": lbl_bg,
            "btn_bg": btn_bg,
            "lbl_fg": lbl_fg,
            "btn_fg": btn_fg,
            "lbl_acc": lbl_acc,
            "btn_acc": btn_acc,
            "lbl_font": lbl_font,
            "font_cb": font_cb,
            "lbl_fs": lbl_fs,
            "fs_cb": fs_cb,
        }

    def _apply_settings_lang(self):
        try:
            win = getattr(self, "settings_win", None)
            widgets = getattr(self, "settings_widgets", None)
            if not win or not widgets:
                return
            win.title(self._t("settings_title"))
            widgets["cb_clip"].configure(text=self._t("monitor_clipboard"))
            widgets["cb_keep"].configure(text=self._t("keep_history"))
            widgets["ocr_label"].configure(text=self._t("ocr_area"))
            widgets["btn_sel"].configure(text=self._t("select_area"))
            widgets["btn_sel_visual"].configure(text=self._t("select_area_visual"))
            widgets["btn_ocr"].configure(text=self._t("toggle_ocr"))
            widgets["lbl_ui"].configure(text=self._t("settings_ui_lang"))
            ui = getattr(self, "ui_lang", "pt")
            vals = [f"{code} - {_language_display_name(code, ui)}" for code, _ in UI_LANG_CHOICES]
            widgets["ui_cb"]["values"] = vals
            try:
                idx = [c for c, _ in UI_LANG_CHOICES].index(self.ui_lang)
            except Exception:
                idx = 0
            widgets["ui_cb"].current(idx)
            if "lbl_side" in widgets:
                widgets["lbl_side"].configure(text=self._t("floating_button_side"))
            if "side_cb" in widgets:
                widgets["side_cb"]["values"] = [self._t("left"), self._t("right")]
                widgets["side_cb"].set(self._t("right") if self.floating_side == "right" else self._t("left"))
            if "lbl_theme" in widgets:
                widgets["lbl_theme"].configure(text=self._t("theme"))
            if "theme_cb" in widgets:
                widgets["theme_cb"]["values"] = [self._t("light_mode"), self._t("dark_mode"), self._t("ocean_theme"), self._t("forest_theme"), self._t("custom_theme")]
                if self.theme == "dark":
                    widgets["theme_cb"].set(self._t("dark_mode"))
                elif self.theme == "light":
                    widgets["theme_cb"].set(self._t("light_mode"))
                elif self.theme == "ocean":
                    widgets["theme_cb"].set(self._t("ocean_theme"))
                elif self.theme == "forest":
                    widgets["theme_cb"].set(self._t("forest_theme"))
                else:
                    widgets["theme_cb"].set(self._t("custom_theme"))
            if "lbl_font" in widgets:
                widgets["lbl_font"].configure(text=self._t("font_label"))
            if "font_cb" in widgets:
                try:
                    fams = sorted(set(list(tkfont.families(self)) + ["Jokerman"]))
                except Exception:
                    fams = [self.font_family]
                widgets["font_cb"]["values"] = fams
                widgets["font_cb"].set(self.font_family)
            if "lbl_fs" in widgets:
                widgets["lbl_fs"].configure(text=self._t("font_size"))
            if "fs_cb" in widgets:
                widgets["fs_cb"]["values"] = ["9","10","11","12","14","16","18"]
                widgets["fs_cb"].set(str(self.font_size))
            for k in ("lbl_bg", "btn_bg", "lbl_fg", "btn_fg", "lbl_acc", "btn_acc"):
                if k in widgets:
                    if self.theme == "custom":
                        try:
                            widgets[k].configure(text=self._t({"lbl_bg":"bg_color","btn_bg":"bg_color","lbl_fg":"fg_color","btn_fg":"fg_color","lbl_acc":"acc_color","btn_acc":"acc_color"}[k]))
                        except Exception:
                            pass
                        try:
                            widgets[k].pack_configure()
                        except Exception:
                            pass
                    else:
                        try:
                            widgets[k].pack_forget()
                        except Exception:
                            pass
        except Exception:
            pass

    def _apply_theme(self):
        try:
            style = ttk.Style(self)
            try:
                if self._font is None:
                    self._font = tkfont.Font(family=self.font_family, size=self.font_size)
            except Exception:
                pass
            if self.theme == "dark":
                try:
                    style.theme_use("clam")
                except Exception:
                    pass
                bg = "#121212"
                fg = "#eaeaea"
                acc = "#1e1e1e"
                self.configure(bg=bg)
                style.configure("TFrame", background=bg)
                style.configure("TLabel", background=bg, foreground=fg, font=self._font)
                style.configure("TButton", background="#000000", foreground=fg, font=self._font)
                try:
                    style.map("TButton",
                              foreground=[("active", fg), ("pressed", fg), ("disabled", "#9a9a9a")],
                              background=[("active", "#000000"), ("pressed", "#000000")])
                except Exception:
                    pass
                style.configure("TCheckbutton", background=bg, foreground=fg, font=self._font)
                style.configure("TCombobox", fieldbackground=acc, foreground=fg, background=acc, font=self._font)
                try:
                    self.input_text.configure(bg=acc, fg=fg, insertbackground=fg, font=self._font)
                except Exception:
                    pass
                try:
                    self.output_text.configure(bg=acc, fg=fg, insertbackground=fg, font=self._font)
                except Exception:
                    pass
                try:
                    if getattr(self, "settings_win", None):
                        self.settings_win.configure(bg=bg)
                except Exception:
                    pass
            elif self.theme == "light":
                try:
                    style.theme_use("vista")
                except Exception:
                    pass
                bg = "#f0f0f0"
                fg = "#000000"
                acc = "#ffffff"
                self.configure(bg=bg)
                style.configure("TFrame", background=bg)
                style.configure("TLabel", background=bg, foreground=fg, font=self._font)
                style.configure("TButton", background=acc, foreground=fg, font=self._font)
                try:
                    style.map("TButton",
                              foreground=[("active", fg), ("pressed", fg), ("disabled", "#888888")],
                              background=[("active", acc), ("pressed", acc)])
                except Exception:
                    pass
                style.configure("TCheckbutton", background=bg, foreground=fg, font=self._font)
                style.configure("TCombobox", fieldbackground=acc, foreground=fg, background=acc, font=self._font)
                try:
                    self.input_text.configure(bg=acc, fg=fg, insertbackground="#333333", font=self._font)
                except Exception:
                    pass
                try:
                    self.output_text.configure(bg=acc, fg=fg, insertbackground="#333333", font=self._font)
                except Exception:
                    pass
                try:
                    if getattr(self, "settings_win", None):
                        self.settings_win.configure(bg=bg)
                except Exception:
                    pass
            elif self.theme == "ocean":
                try:
                    style.theme_use("clam")
                except Exception:
                    pass
                bg = "#0e2a47"
                fg = "#e8f1f8"
                acc = "#1b4b7a"
                self.configure(bg=bg)
                style.configure("TFrame", background=bg)
                style.configure("TLabel", background=bg, foreground=fg, font=self._font)
                style.configure("TButton", background="#000000", foreground=fg, font=self._font)
                try:
                    style.map("TButton",
                              foreground=[("active", fg), ("pressed", fg), ("disabled", "#99b3c8")],
                              background=[("active", "#000000"), ("pressed", "#000000")])
                except Exception:
                    pass
                style.configure("TCheckbutton", background=bg, foreground=fg, font=self._font)
                style.configure("TCombobox", fieldbackground=acc, foreground=fg, background=acc, font=self._font)
                try:
                    self.input_text.configure(bg=acc, fg=fg, insertbackground=fg, font=self._font)
                except Exception:
                    pass
                try:
                    self.output_text.configure(bg=acc, fg=fg, insertbackground=fg, font=self._font)
                except Exception:
                    pass
                try:
                    if getattr(self, "settings_win", None):
                        self.settings_win.configure(bg=bg)
                except Exception:
                    pass
            elif self.theme == "forest":
                try:
                    style.theme_use("clam")
                except Exception:
                    pass
                bg = "#0f2f1c"
                fg = "#e6f0e6"
                acc = "#1c5c34"
                self.configure(bg=bg)
                style.configure("TFrame", background=bg)
                style.configure("TLabel", background=bg, foreground=fg, font=self._font)
                style.configure("TButton", background="#000000", foreground=fg, font=self._font)
                try:
                    style.map("TButton",
                              foreground=[("active", fg), ("pressed", fg), ("disabled", "#a9c4b0")],
                              background=[("active", "#000000"), ("pressed", "#000000")])
                except Exception:
                    pass
                style.configure("TCheckbutton", background=bg, foreground=fg, font=self._font)
                style.configure("TCombobox", fieldbackground=acc, foreground=fg, background=acc, font=self._font)
                try:
                    self.input_text.configure(bg=acc, fg=fg, insertbackground=fg, font=self._font)
                except Exception:
                    pass
                try:
                    self.output_text.configure(bg=acc, fg=fg, insertbackground=fg, font=self._font)
                except Exception:
                    pass
                try:
                    if getattr(self, "settings_win", None):
                        self.settings_win.configure(bg=bg)
                except Exception:
                    pass
            else:
                try:
                    style.theme_use("clam")
                except Exception:
                    pass
                bg = self.custom_palette.get("bg") or "#202020"
                fg = self.custom_palette.get("fg") or "#eaeaea"
                acc = self.custom_palette.get("acc") or "#2d2d2d"
                self.configure(bg=bg)
                style.configure("TFrame", background=bg)
                style.configure("TLabel", background=bg, foreground=fg, font=self._font)
                style.configure("TButton", background="#000000", foreground=fg, font=self._font)
                try:
                    style.map("TButton",
                              foreground=[("active", fg), ("pressed", fg), ("disabled", "#b0b0b0")],
                              background=[("active", "#000000"), ("pressed", "#000000")])
                except Exception:
                    pass
                style.configure("TCheckbutton", background=bg, foreground=fg, font=self._font)
                style.configure("TCombobox", fieldbackground=acc, foreground=fg, background=acc, font=self._font)
                try:
                    self.input_text.configure(bg=acc, fg=fg, insertbackground=fg, font=self._font)
                except Exception:
                    pass
                try:
                    self.output_text.configure(bg=acc, fg=fg, insertbackground=fg, font=self._font)
                except Exception:
                    pass
                try:
                    if getattr(self, "settings_win", None):
                        self.settings_win.configure(bg=bg)
                except Exception:
                    pass
        except Exception:
            pass

    def _palette(self):
        if self.theme == "dark":
            return ("#121212", "#eaeaea", "#1e1e1e")
        if self.theme == "light":
            return ("#f0f0f0", "#000000", "#ffffff")
        if self.theme == "ocean":
            return ("#0e2a47", "#e8f1f8", "#1b4b7a")
        if self.theme == "forest":
            return ("#0f2f1c", "#e6f0e6", "#1c5c34")
        return (
            self.custom_palette.get("bg") or "#202020",
            self.custom_palette.get("fg") or "#eaeaea",
            self.custom_palette.get("acc") or "#2d2d2d",
        )

    def _toggle_clipboard_monitor(self):
        if self.monitor_clipboard_var.get():
            if not HAS_PYPERCLIP:
                _ensure_imports()
            if not HAS_PYPERCLIP:
                messagebox.showerror(self._t("error"), self._t("missing_pyperclip_msg"))
                self.monitor_clipboard_var.set(False)
                return
            if self.clipboard_running:
                return
            self.clipboard_running = True
            threading.Thread(target=self._clipboard_loop, daemon=True).start()
        else:
            self.clipboard_running = False

    def _clipboard_loop(self):
        prev = None
        while self.clipboard_running:
            try:
                txt = pyperclip.paste()
            except Exception:
                txt = None
            if txt and txt != prev:
                prev = txt
                src = self._parse_lang(self.source_var.get())
                dst = self._parse_lang(self.target_var.get())
                try:
                    data = translate_text(txt, dst, None if src == "auto" else src)
                except Exception as e:
                    self.after(0, lambda: messagebox.showerror(self._t("error"), str(e)))
                else:
                    self.after(0, lambda d=data: self._append_history(d))
            time.sleep(0.8)

    def _select_bbox_dialog(self):
        dlg = tk.Toplevel(self)
        dlg.title(self._t("ocr_area"))
        dlg.attributes("-topmost", True)
        frm = ttk.Frame(dlg)
        frm.pack(padx=12, pady=12)
        x_var = tk.IntVar(value=100)
        y_var = tk.IntVar(value=100)
        w_var = tk.IntVar(value=600)
        h_var = tk.IntVar(value=200)
        ttk.Label(frm, text="x").grid(row=0, column=0)
        ttk.Entry(frm, textvariable=x_var, width=8).grid(row=0, column=1)
        ttk.Label(frm, text="y").grid(row=0, column=2)
        ttk.Entry(frm, textvariable=y_var, width=8).grid(row=0, column=3)
        ttk.Label(frm, text="w").grid(row=1, column=0)
        ttk.Entry(frm, textvariable=w_var, width=8).grid(row=1, column=1)
        ttk.Label(frm, text="h").grid(row=1, column=2)
        ttk.Entry(frm, textvariable=h_var, width=8).grid(row=1, column=3)
        def save():
            x, y, w, h = x_var.get(), y_var.get(), w_var.get(), h_var.get()
            self.ocr_bbox = (x, y, x + w, y + h)
            self._save_config()
            dlg.destroy()
        ttk.Button(frm, text=self._t("save"), command=save).grid(row=2, column=0, columnspan=4, pady=8)

    def _toggle_ocr(self):
        if self.ocr_running:
            self.ocr_running = False
            return
        if not (HAS_TESSERACT and HAS_MSS and HAS_PIL):
            _ensure_imports()
        if not (HAS_TESSERACT and HAS_MSS and HAS_PIL):
            messagebox.showerror(self._t("error"), self._t("missing_ocr_deps_msg"))
            return
        try:
            cmd = _find_tesseract_cmd()
            if cmd:
                pytesseract.pytesseract.tesseract_cmd = cmd
        except Exception:
            pass
        if not self.ocr_bbox:
            messagebox.showinfo(self._t("info"), self._t("define_ocr_area_msg"))
            return
        self.ocr_running = True
        threading.Thread(target=self._ocr_loop, daemon=True).start()

    def _select_bbox_visual(self):
        if not (HAS_MSS and HAS_PIL):
            _ensure_imports()
        if not (HAS_MSS and HAS_PIL):
            messagebox.showerror(self._t("error"), self._t("missing_visual_deps_msg"))
            return
        with mss.mss() as sct:
            mon = sct.monitors[1]
            shot = sct.grab(mon)
            img = Image.frombytes("RGB", shot.size, shot.rgb)
        win = tk.Toplevel(self)
        win.title(self._t("select_area_visual"))
        win.attributes("-topmost", True)
        win.state("zoomed")
        canvas = tk.Canvas(win, highlightthickness=0)
        canvas.pack(fill=tk.BOTH, expand=True)
        tkimg = ImageTk.PhotoImage(img)
        canvas.create_image(0, 0, anchor=tk.NW, image=tkimg)
        start_x = start_y = 0
        rect_id = None
        def on_press(e):
            nonlocal start_x, start_y, rect_id
            start_x, start_y = e.x, e.y
            if rect_id is not None:
                canvas.delete(rect_id)
            rect_id = canvas.create_rectangle(e.x, e.y, e.x, e.y, outline="red", width=2)
        def on_move(e):
            if rect_id is not None:
                canvas.coords(rect_id, start_x, start_y, e.x, e.y)
        def on_release(e):
            nonlocal rect_id
            x0, y0 = start_x, start_y
            x1, y1 = e.x, e.y
            if x1 < x0:
                x0, x1 = x1, x0
            if y1 < y0:
                y0, y1 = y1, y0
            self.ocr_bbox = (mon["left"] + x0, mon["top"] + y0, mon["left"] + x1, mon["top"] + y1)
            self._save_config()
            win.destroy()
        def on_escape(e):
            win.destroy()
        canvas.bind("<ButtonPress-1>", on_press)
        canvas.bind("<B1-Motion>", on_move)
        canvas.bind("<ButtonRelease-1>", on_release)
        win.bind("<Escape>", on_escape)

    def _ocr_loop(self):
        with mss.mss() as sct:
            while self.ocr_running:
                try:
                    x0, y0, x1, y1 = self.ocr_bbox
                    region = {"left": x0, "top": y0, "width": x1 - x0, "height": y1 - y0}
                    shot = sct.grab(region)
                    img = Image.frombytes("RGB", shot.size, shot.rgb)
                    text = pytesseract.image_to_string(img)
                except Exception:
                    text = ""
                if text and text.strip():
                    src = self._parse_lang(self.source_var.get())
                    dst = self._parse_lang(self.target_var.get())
                    try:
                        data = translate_text(text.strip(), dst, None if src == "auto" else src)
                    except Exception as e:
                        self.after(0, lambda: messagebox.showerror(self._t("error"), str(e)))
                    else:
                        self.after(0, lambda d=data: self._append_history(d))
                time.sleep(1.2)

def parse_args(argv):
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["cli", "gui"], default="gui")
    p.add_argument("--target", default="pt")
    p.add_argument("--source", default="auto")
    p.add_argument("--text", default=None)
    return p.parse_args(argv)

def main(argv=None):
    args = parse_args(argv or sys.argv[1:])
    if args.mode == "cli":
        cli_mode(args)
    else:
        _ensure_imports()
        app = TranslatorApp()
        app.mainloop()

if __name__ == "__main__":
    main()
